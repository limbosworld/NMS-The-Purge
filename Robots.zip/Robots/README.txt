A Collection of JSON Save Files to use in NMSSE

About the 3 DDS files:
If you put them in your cache folder, it should populate the base teleporter list with thumbnails of the bases in this save file.



If you notice anything wrong with the files, please let me know.

-Limbo506